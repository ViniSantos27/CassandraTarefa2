package Service;





import Model.PopDiva;
import Repository.PopDivaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class PopDivaService {

    @Autowired
    private PopDivaRepository popDivaRepository;

    // Retorna todos os registros de PopDiva
    public List<PopDiva> getAllDivas() {
        return popDivaRepository.findAll();
    }

    // Retorna um registro de PopDiva pelo ID
    public Optional<PopDiva> getDivaById(UUID divaId) {
        return popDivaRepository.findById(divaId);
    }

    // Adiciona um novo registro de PopDiva
    public PopDiva addDiva(PopDiva popDiva) {
        return popDivaRepository.save(popDiva);
    }

    // Remove um registro de PopDiva pelo ID
    public void deleteDiva(UUID divaId) {
        popDivaRepository.deleteById(divaId);
    }
}

