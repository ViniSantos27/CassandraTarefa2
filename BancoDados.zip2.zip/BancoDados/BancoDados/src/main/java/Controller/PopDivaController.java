package Controller;



import Model.PopDiva;
import Service.PopDivaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/divas")
public class PopDivaController {

    @Autowired
    private PopDivaService popDivaService;

    // Endpoint para obter todos os registros de PopDiva
    @GetMapping
    public List<PopDiva> getAllDivas() {
        return popDivaService.getAllDivas();
    }

    // Endpoint para obter um registro de PopDiva pelo ID
    @GetMapping("/{id}")
    public ResponseEntity<PopDiva> getDivaById(@PathVariable UUID id) {
        Optional<PopDiva> diva = popDivaService.getDivaById(id);
        return diva.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Endpoint para adicionar um novo registro de PopDiva
    @PostMapping
    public PopDiva addDiva(@RequestBody PopDiva popDiva) {
        return popDivaService.addDiva(popDiva);
    }

    // Endpoint para remover um registro de PopDiva pelo ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDiva(@PathVariable UUID id) {
        popDivaService.deleteDiva(id);
        return ResponseEntity.noContent().build();
    }
}
